module.exports = {
  connection: {
    host     : "db.it.pointpark.edu",
    user     : "vetmove",
    password : "vetmove",
    database : "vetmove"
  }
};
